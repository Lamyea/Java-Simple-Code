
public class DoublyLL {
	//Represent a node of the doubly linked lis
	class Node{
		int data;
		Node previous;
		Node next;
		
		public Node(int data) {
			this.data = data;
		}
	}
//Represent the head and tail of the doubly linked list
	Node head, tail = null;
	
	//addNode() will add a node to the list
	public void addNode(int data) {
		//Create a new node
		Node newNode = new Node(data);
		
		//If list is empty
		if(head == null) {
			//Both head and tail will point to newNode
			head = tail = newNode;
			//Head's previous will point to null
			head.previous = null;
			//tail's next will point to null, as it is the last node of the list
			tail.next = null;
		} else {
			//newNode will be added after tail such that tail's next will point to newNode
			tail.next = newNode;
			//newNode's previous will point to tail
			newNode.previous = tail;
			//newNode will become new tail
			tail = newNode;
			//As it is last node, tails next will point to null
			tail.next = null;
		}
	}
	
	//reverse 
    public void reverse() {  
        //Node current will point to head  
        Node current = head, temp = null;  
  
        //Swap the previous and next pointers of each node to reverse the direction of the list  
        while(current != null) {  
            temp = current.next;  
            current.next = current.previous;  
            current.previous = temp;  
            current = current.previous;  
        }  
        //Swap the head and tail pointers.  
        temp = head;  
        head = tail;  
        tail = temp;  
    } 
    
    //MinimumNode() will find out minimum value node in the list  
    public int minimumNode() {  
        //Node current will point to head  
        Node current = head;  
        int min;  
  
        //Checks if list is empty  
        if(head == null) {  
            System.out.println("List is empty");  
            return 0;  
        }  
        else {  
            //Initially, min will store the value of head's data  
            min = head.data;  
            while(current != null) {  
                //If the value of min is greater than the current's data  
  
                //Then, replace the value of min with current node's data  
  
                if(min > current.data)  
                    min = current.data;  
                current = current.next;  
            }  
        }  
        return min;  
    }  
    //MaximumNode() will find out maximum value node in the list  
    public int maximumNode() {  
        //Node current will point to head  
        Node current = head;  
        int max;  
  
        //Checks if list is empty  
        if(head == null) {  
            System.out.println("List is empty");  
            return 0;  
        }  
        else {  
            //Initially, max will store the value of head's data  
            max = head.data;  
            //If value of max is lesser than current's data  
            //Then, replace value of max with current node's data  
            while(current != null) {  
                if(current.data > max)  
                    max = current.data;  
                current = current.next;  
            }  
        }  
        return max;  
    }  
    
    //removeDuplicateNode() will remove duplicate nodes from the list  
    public void removeDuplicateNode() {  
        //Node current will point to head  
        Node current, index, temp;  
  
        //Checks whether list is empty  
        if(head == null) {  
            return;  
        }  
        else {  
            //Initially, current will point to head node  
            for(current = head; current != null; current = current.next) {  
                //index will point to node next to current  
                for(index = current.next; index != null; index = index.next) {  
                    if(current.data == index.data) {  
                        //Store the duplicate node in temp  
                        temp = index;  
                        //index's previous node will point to node next to index thus, removes the duplicate node  
                        index.previous.next = index.next;  
                        if(index.next != null)  
                            index.next.previous = index.previous;  
                        //Delete duplicate node by making temp to null  
                        temp = null;  
                    }  
                }  
            }  
        }  
    }  
	
	//countNodes() will count the nodes present in the list
	public int countNodes() {
		int counter = 0;
		//Node current will point to head
		Node current = head;
		
		while(current!= null) {
			//increment the counter by 1 for each node
			counter++;
			current = current.next;
		}
		return counter;
	}
	
	//display() will print out the elements of the list
	public void display() {
		//Node current will point to head
		Node current = head;
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		System.out.println("Nodes of doubly linked list: ");
		while(current != null) {
			//Prints each node by incrementing the pointer
			
			System.out.print(current.data+ " ");
			current = current.next;
		}
	}
	public static void main(String[] args) {
		DoublyLL dList = new DoublyLL();
		//Add nodes to the list
        dList.addNode(1);  
        dList.addNode(2);  
        dList.addNode(3);  
        dList.addNode(4);  
        dList.addNode(5);  
  
        //Displays the nodes present in the list  
        dList.display();  
  
        //Counts the nodes present in the given list  
        System.out.println("\nCount of nodes present in the list: " + dList.countNodes());
        
        
        //Prints the minimum value node in the list  
        System.out.println("Minimum value node in the list: "+ dList.minimumNode());  
        //Prints the maximum value node in the list  
        System.out.println("Maximum value node in the list: "+ dList.maximumNode());  
        
        
        //Reverse the given list  
        dList.reverse();  
  
        //Displays the reversed list  
        System.out.println("\nReversed List: ");  
        dList.display();  
        
        //Removes duplicate nodes
        dList.removeDuplicateNode();
	

	}

}
