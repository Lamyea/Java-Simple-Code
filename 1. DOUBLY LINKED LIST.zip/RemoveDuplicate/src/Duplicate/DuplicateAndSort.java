package Duplicate;

public class DuplicateAndSort { //remove duplicate and sort the list
	//Represernt a node of the doubly linked list
	class Node{
		int data;
		Node previous;
		Node next;
		
		public Node(int data) {
			this.data = data;
		}
	}
	
	Node head, tail = null;
	
	public void addNode(int data) {
		Node newNode = new Node(data);
		if(head == null) {
			head = tail = newNode;
			head.previous = null;
			tail.next = null;
		} else {
			tail.next = newNode;
			newNode.previous = tail;
			tail = newNode;
			tail.next = null;
		}
	}
	
	public void removeDuplicateNode() {
		//Node current will point to head
		Node current, index, temp;
		if(head ==  null) {
			return;
		} else {
			//Initially, current will point to head node
			for(current = head; current != null; current = current.next) {
			//index will point to node next to current
				for(index = current.next; index != null; index = index.next) {
					if(current.data == index.data) {
						//Store the duplicate node in temp
						temp = index;
						//Index's previous node will point to node next to index thus, removes the duplicate node
						index.previous.next = index.next;
						if(index.next != null)
							index.next.previous = index.previous;
						//Delete duplicate node by making temp to null
						temp = null;
					}
				}
			}
		}
	}
	//sortList() will sort the given list in ascending  order
    public void sortList() {  
        Node current = null, index = null;  
        int temp;  
        //Check whether list is empty  
        if(head == null) {  
            return;  
        }  
        else {  
            //Current will point to head  
            for(current = head; current.next != null; current = current.next) {  
                //Index will point to node next to current  
                for(index = current.next; index != null; index = index.next) {  
                    //If current's data is greater than index's data, swap the data of current and index  
                    if(current.data > index.data) {  
                        temp = current.data;  
                        current.data = index.data;  
                        index.data = temp;  
                    }  
                }  
            }  
        }  
    } 
	
	//display() will print out the nodes of the list
	public void display() {
		//Node current will point to head
		Node current = head;
		if(head == null) {
			System.out.println("List is empty");
			return;
		} while(current!= null) {
			//Prints each node by incrementing the pointer
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}
	
    public static void main(String[] args) {  
    	  
    	DuplicateAndSort dList = new DuplicateAndSort();  
        //Add nodes to the list  
    	dList.addNode(5);
    	dList.addNode(3);
        dList.addNode(1);  
        dList.addNode(2);  
        dList.addNode(3);  
        dList.addNode(2);  
        dList.addNode(2);  
        dList.addNode(4);  
          
          
  
        System.out.println("Originals list: ");  
        dList.display();  
  
        //Removes duplicate nodes  
        dList.removeDuplicateNode();  
  
        System.out.println("List after removing duplicates: ");  
        dList.display();  
        
        //Sorting list  
        dList.sortList();  
  
        //Displaying sorted list  
        System.out.println("Sorted list: ");  
        dList.display();  
    } 

}
